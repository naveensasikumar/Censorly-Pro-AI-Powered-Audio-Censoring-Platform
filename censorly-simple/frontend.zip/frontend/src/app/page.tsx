'use client'

import { useState, useEffect } from 'react'
import { Upload, Settings, Download, Music, CheckCircle, Clock, AlertCircle } from 'lucide-react'
import axios from 'axios'

interface ProcessingFile {
  file_id: string
  original_name: string
  status: 'queued' | 'processing' | 'completed' | 'error'
  words_censored?: number
  transcript?: string
  error?: string
}

interface JobStatus {
  job_id: string
  status: 'processing' | 'completed' | 'error'
  progress: number
  total_files: number
  completed_files: number
  download_ready: boolean
  files: ProcessingFile[]
}

const API_BASE_URL = 'http://localhost:8000'

export default function HomePage() {
  const [files, setFiles] = useState<File[]>([])
  const [severity, setSeverity] = useState('children')
  const [isProcessing, setIsProcessing] = useState(false)
  const [jobId, setJobId] = useState<string | null>(null)
  const [jobStatus, setJobStatus] = useState<JobStatus | null>(null)
  const [downloadLinks, setDownloadLinks] = useState<any[]>([])

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files))
    }
  }

  const handleProcess = async () => {
    if (files.length === 0) return

    setIsProcessing(true)
    setJobStatus(null)
    setDownloadLinks([])

    try {
      const formData = new FormData()
      files.forEach(file => {
        formData.append('files', file)
      })
      formData.append('severity', severity)

      const response = await axios.post(`${API_BASE_URL}/api/upload`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      })

      const { job_id } = response.data
      setJobId(job_id)
      
      // Start polling for status
      pollJobStatus(job_id)

    } catch (error) {
      console.error('Upload failed:', error)
      alert('Upload failed. Please try again.')
      setIsProcessing(false)
    }
  }

  const pollJobStatus = async (jobId: string) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/api/status/${jobId}`)
      const status: JobStatus = response.data

      setJobStatus(status)

      if (status.status === 'completed') {
        setIsProcessing(false)
        // Get download links
        const downloadResponse = await axios.get(`${API_BASE_URL}/api/download/${jobId}`)
        setDownloadLinks(downloadResponse.data.files || [])
      } else if (status.status === 'error') {
        setIsProcessing(false)
        alert('Processing failed. Please try again.')
      } else {
        // Continue polling
        setTimeout(() => pollJobStatus(jobId), 2000)
      }
    } catch (error) {
      console.error('Status check failed:', error)
      setIsProcessing(false)
    }
  }

  const downloadFile = (url: string, filename: string) => {
    const link = document.createElement('a')
    link.href = `${API_BASE_URL}${url}`
    link.download = filename
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'processing':
        return <Clock className="h-4 w-4 text-blue-500" />
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />
      default:
        return <Clock className="h-4 w-4 text-gray-400" />
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Music className="h-8 w-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-900">Censorly</h1>
          </div>
          <p className="text-gray-600">AI-Powered Audio Censoring Tool</p>
        </div>

        {/* Upload Section */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            <Upload className="h-5 w-5 mr-2" />
            Upload Audio Files
          </h2>
          
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
            <input
              type="file"
              multiple
              accept="audio/*"
              onChange={handleFileChange}
              className="hidden"
              id="file-upload"
              disabled={isProcessing}
            />
            <label htmlFor="file-upload" className={`cursor-pointer ${isProcessing ? 'opacity-50' : ''}`}>
              <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">
                Click to upload or drag and drop audio files
              </p>
              <p className="text-sm text-gray-400 mt-2">
                MP3, WAV, M4A files supported
              </p>
            </label>
          </div>

          {files.length > 0 && (
            <div className="mt-4">
              <h3 className="font-medium mb-2">Selected Files:</h3>
              <ul className="space-y-2">
                {files.map((file, index) => (
                  <li key={index} className="flex items-center space-x-2 text-sm">
                    <Music className="h-4 w-4 text-blue-600" />
                    <span>{file.name}</span>
                    <span className="text-gray-500">
                      ({(file.size / 1024 / 1024).toFixed(2)} MB)
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Settings Section */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            <Settings className="h-5 w-5 mr-2" />
            Censoring Level
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { id: 'children', label: 'Children Mode', desc: 'Maximum filtering' },
              { id: 'teen', label: 'Teen 13+', desc: 'Balanced filtering' },
              { id: 'adult', label: 'Adult 16+', desc: 'Light filtering' }
            ].map((option) => (
              <label key={option.id} className="cursor-pointer">
                <input
                  type="radio"
                  name="severity"
                  value={option.id}
                  checked={severity === option.id}
                  onChange={(e) => setSeverity(e.target.value)}
                  className="sr-only"
                  disabled={isProcessing}
                />
                <div className={`border-2 rounded-lg p-4 text-center transition-colors ${
                  severity === option.id 
                    ? 'border-blue-500 bg-blue-50' 
                    : 'border-gray-200 hover:border-gray-300'
                } ${isProcessing ? 'opacity-50' : ''}`}>
                  <h3 className="font-medium">{option.label}</h3>
                  <p className="text-sm text-gray-600">{option.desc}</p>
                </div>
              </label>
            ))}
          </div>
        </div>

        {/* Process Button */}
        <div className="text-center mb-6">
          <button
            onClick={handleProcess}
            disabled={files.length === 0 || isProcessing}
            className={`px-8 py-3 rounded-lg font-medium transition-colors ${
              files.length === 0 || isProcessing
                ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                : 'bg-blue-600 text-white hover:bg-blue-700'
            }`}
          >
            {isProcessing ? 'Processing...' : 'Start Censoring'}
          </button>
        </div>

        {/* Processing Status */}
        {jobStatus && (
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 className="text-xl font-semibold mb-4">Processing Status</h2>
            
            {/* Overall Progress */}
            <div className="mb-4">
              <div className="flex justify-between text-sm text-gray-600 mb-1">
                <span>Overall Progress</span>
                <span>{jobStatus.progress.toFixed(1)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${jobStatus.progress}%` }}
                ></div>
              </div>
              <p className="text-sm text-gray-500 mt-1">
                {jobStatus.completed_files} of {jobStatus.total_files} files completed
              </p>
            </div>

            {/* File Status */}
            <div className="space-y-3">
              {jobStatus.files.map((file, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    {getStatusIcon(file.status)}
                    <div>
                      <p className="font-medium text-sm">{file.original_name}</p>
                      <p className="text-xs text-gray-500 capitalize">{file.status}</p>
                    </div>
                  </div>
                  
                  {file.words_censored !== undefined && (
                    <div className="text-right">
                      <p className="text-sm font-medium text-blue-600">
                        {file.words_censored} words censored
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Download Section */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            <Download className="h-5 w-5 mr-2" />
            Download Censored Files
          </h2>
          
          {downloadLinks.length > 0 ? (
            <div className="space-y-3">
              {downloadLinks.map((file, index) => (
                <div key={index} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                  <div className="flex-1">
                    <h3 className="font-medium">{file.original_name}</h3>
                    <p className="text-sm text-gray-600">
                      {file.words_censored} words censored
                    </p>
                    {file.transcript_preview && (
                      <p className="text-xs text-gray-500 mt-1 truncate">
                        "{file.transcript_preview}"
                      </p>
                    )}
                  </div>
                  <button
                    onClick={() => downloadFile(file.download_url, `censored_${file.original_name}`)}
                    className="ml-4 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                  >
                    Download
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-600">Processed files will appear here...</p>
          )}
        </div>

      </div>
    </div>
  )
}